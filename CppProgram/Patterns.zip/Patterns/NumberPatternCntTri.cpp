#include<iostream>
using namespace std;

int main() {
	int n;
	cout<<"Enter A number "<<endl;
	cin>>n;

	int cnt = 1;	
	for(int i = 1;i<=n;i++) {
		for(int j =1;j<=i;j++){
			cout<<cnt;
			cnt++;
		}
		cout<<endl;
	}

}

/* 

1
23
456

*/