#include<iostream>
using namespace std;

int main() {
	int n;
	cout<<"Enter A number "<<endl;
	cin>>n;

	for(int i = 1; i<=n;i++) {
		for(int j =1 ; j <= i;j++) {
			cout<<i-j+1;
		}
		cout<<endl;
	}
}
/*  OuTpuT

1 
21
321
4321

*/